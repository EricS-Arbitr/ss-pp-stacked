# Docker Role

## Description
Installs Docker and Docker Compose on Ubuntu/Debian systems. The role configures APT to use the cyber range proxy, adds the official Docker repository, and installs the Docker engine with all required components.

## Variable Definition Location
Variables for this role should be defined in **group_vars/all.yml**

## Required Variables

### In group_vars/all.yml

| Variable | Required | Description |
|----------|----------|-------------|
| inet_proxy_addr | Yes | Proxy server address for external communication |
| inet_proxy_port | Yes | Proxy server port |

## Complete Example Configuration

### group_vars/all.yml
```yaml
inet_proxy_addr: "10.255.240.1"
inet_proxy_port: "3128"
```
